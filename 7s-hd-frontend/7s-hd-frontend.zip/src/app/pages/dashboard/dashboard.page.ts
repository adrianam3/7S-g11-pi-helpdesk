import { Component, OnInit } from '@angular/core';
import { ToastController } from '@ionic/angular';
import { ApiService } from 'src/app/services/api.service';
import { ChartOptions, ChartType, ChartData, Plugin } from 'chart.js';
import ChartDataLabels from 'chartjs-plugin-datalabels';
import { Chart } from 'chart.js';
import { BaseChartDirective } from 'ng2-charts';
import { ViewChild } from '@angular/core';
import * as XLSX from 'xlsx';
import * as FileSaver from 'file-saver';
import { PopoverController } from '@ionic/angular';
import { PopoverResumenTicketsComponent } from 'src/app/components/popover-resumen-tickets/popover-resumen-tickets.component';
import Plotly from 'plotly.js-dist-min';
// import Plotly from 'plotly.js-dist-min';

Chart.register(ChartDataLabels);

interface EstadoTicket {
  name: string;
  value: number;
}

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.page.html',
  styleUrls: ['./dashboard.page.scss'],
  standalone: false
})
export class DashboardPage implements OnInit {
  public dashboardAll: EstadoTicket[] = [];

  fechaInicio: string = '';
  fechaFin: string = '';
  mostrarInicio = false;
  mostrarFin = false;
  tabSeleccionada: string = 'estado';
  dashboardDeptoEstado: any[] = [];
  dashboardAgente: any[] = [];
  dashboardSatisfaccion: any[] = [];
  resumenSatisfaccionAgente: any[] = [];


  barChartDataAgente: ChartData<'bar'> = { labels: [], datasets: [] };

  @ViewChild(BaseChartDirective) chart?: BaseChartDirective;
  @ViewChild('barChartAgente') barChartAgente!: BaseChartDirective;
  @ViewChild('barChartAgenteCanvas', { static: false }) barChartAgenteCanvasRef: any;



  // Pie chart config con tipos flexibles
  pieChartData: ChartData = {
    labels: [],
    datasets: [
      {
        data: [],
        backgroundColor: []
      }
    ]
  };

  pieChartType: ChartType = 'pie';

  pieChartOptions: ChartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'bottom'
      },
      datalabels: {
        formatter: (value, ctx) => {
          const total = (ctx.chart.data.datasets[0].data as number[]).reduce((a, b) => a + b, 0);
          return ((value * 100) / total).toFixed(1) + '%';
        },
        color: '#fff',
        font: {
          weight: 'bold'
        }
      }
    }
  };

  pieChartPlugins: Plugin[] = [ChartDataLabels];



  constructor(
    private popoverController: PopoverController,
    private toastController: ToastController,
    private apiService: ApiService
  ) { }

  ngOnInit() {
    const today = new Date();
    const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);

    this.fechaInicio = startOfMonth.toISOString().split('T')[0];
    this.fechaFin = today.toISOString().split('T')[0];
    this.cargarTicketXEstado();
    this.cargarPorDepartamentoEstado();
    this.cargarPorAgente();
    this.cargarSatisfaccionUsuario();
    this.cargarResumenSatisfaccionAgente();
  }

  abrirSelector(tipo: 'inicio' | 'fin') {
    tipo === 'inicio' ? (this.mostrarInicio = true) : (this.mostrarFin = true);
  }

  cerrarSelector(tipo: 'inicio' | 'fin') {
    tipo === 'inicio' ? (this.mostrarInicio = false) : (this.mostrarFin = false);
  }

  cambiarFecha(event: any, tipo: 'inicio' | 'fin') {
    const fecha = event.detail.value;
    tipo === 'inicio' ? (this.fechaInicio = fecha) : (this.fechaFin = fecha);
    this.cerrarSelector(tipo);
  }

  async showToast(message: string, color: string) {
    const toast = await this.toastController.create({
      message,
      duration: 2000,
      color
    });
    toast.present();
  }

  async cargarPorDepartamentoEstado() {
    try {
      const endpoint = `controllers/ticket.controller.php?op=dashboarddepartamentoestado&fechaInicio=${this.fechaInicio}&fechaFin=${this.fechaFin}`;
      const data: any = await (await this.apiService.get(endpoint)).toPromise();
      this.dashboardDeptoEstado = data;
    } catch (error) {
      this.showToast('Error al cargar datos de la tabla', 'danger');
      console.error(error);
    }
  }

  async cargarTicketXEstado() {
    if (!this.fechaInicio || !this.fechaFin) {
      this.showToast('Debes seleccionar ambas fechas', 'warning');
      return;
    }

    const fechaInicioFormatted = this.fechaInicio.slice(0, 10);
    const fechaFinFormatted = this.fechaFin.slice(0, 10);

    try {
      const endpoint = `controllers/ticket.controller.php?op=dashboard&fechaInicio=${fechaInicioFormatted}&fechaFin=${fechaFinFormatted}`;
      const data: any = await (await this.apiService.get(endpoint)).toPromise();
      console.log(data);
      this.dashboardAll = data.map((e: { estadot: any; cantidad: any }) => ({
        name: e.estadot,
        value: Number(e.cantidad)
      }));

      const colors = ['#FF6384', '#36A2EB', '#FFCE56', '#8E44AD', '#2ECC71', '#E67E22', '#1ABC9C'];

      this.pieChartData.labels = this.dashboardAll.map(d => d.name);
      this.pieChartData.datasets[0].data = this.dashboardAll.map(d => d.value);
      this.pieChartData.datasets[0].backgroundColor = colors.slice(0, this.dashboardAll.length);

      this.chart?.update(); // fuerza el redibujo del gráfico
    } catch (error) {
      this.showToast('Error al cargar datos del dashboard', 'danger');
      console.error('Error en API:', error);
    }
  }

  // async onSubmit() {
  //   if (!this.fechaInicio || !this.fechaFin) {
  //     this.showToast('Debes seleccionar ambas fechas', 'warning');
  //     return;
  //   }

  //   if (this.tabSeleccionada === 'estado') {
  //     await this.cargarTicketXEstado();
  //   }

  //   if (this.tabSeleccionada === 'departamento') {
  //     await this.cargarPorDepartamentoEstado();
  //   }

  //   if (this.tabSeleccionada === 'agente') {
  //     await this.cargarPorAgente();
  //   }

  //   if (this.tabSeleccionada === 'satisfaccion') {
  //     await this.cargarSatisfaccionUsuario();

  //   }
  //   if (this.tabSeleccionada === 'satisfaccionTabla') {
  //     await this.cargarResumenSatisfaccionAgente();
  //   }

  //   if (this.tabSeleccionada === 'satisfaccionGrafico') {
  //     await this.cargarResumenSatisfaccionAgente();
  //   }
  //   if (this.tabSeleccionada === 'velocimetro') {
  //     await this.cargarResumenSatisfaccionAgente();
  //   }



  // }

  async onSubmit() {
    if (!this.fechaInicio || !this.fechaFin) {
      this.showToast('Debes seleccionar ambas fechas', 'warning');
      return;
    }

    // Siempre recargamos estos dos para que el NPS y resumen estén actualizados
    await this.cargarSatisfaccionUsuario();
    await this.cargarResumenSatisfaccionAgente();

    switch (this.tabSeleccionada) {
      case 'estado':
        await this.cargarTicketXEstado();
        break;
      case 'departamento':
        await this.cargarPorDepartamentoEstado();
        break;
      case 'agente':
        await this.cargarPorAgente();
        break;
      case 'satisfaccion':
        // ya se cargó arriba
        break;
      case 'satisfaccionTabla':
      case 'satisfaccionGrafico':
      case 'velocimetro':
      case 'nps':
      case 'npsGrafico':
        // ya se cargó arriba
        break;
    }
  }


  async cargarPorAgente() {
    if (!this.fechaInicio || !this.fechaFin) {
      this.showToast('Debes seleccionar ambas fechas', 'warning');
      return;
    }

    const fechaInicioFormatted = this.fechaInicio.slice(0, 10);
    const fechaFinFormatted = this.fechaFin.slice(0, 10);

    try {
      const endpoint = `controllers/ticket.controller.php?op=dashboardagente&fechaInicio=${fechaInicioFormatted}&fechaFin=${fechaFinFormatted}`;
      const data = await (await this.apiService.get(endpoint)).toPromise() as any[];


      this.dashboardAgente = data;

      const estados = ['Abierto', 'Asignado', 'EnProgreso', 'Cerrado', 'Reaperturado', 'Escalado'];

      this.barChartData = {
        labels: data.map(a => a.agente),
        datasets: estados.map((estado, index) => ({
          label: estado.replace('EnProgreso', 'En Progreso'),
          data: data.map(a => Number(a[estado]) || 0),
          backgroundColor: this.getColorByIndex(index),
          stack: 'a' // 🔹 Para que todos se apilen juntos
        }))
      };

    } catch (error) {
      this.showToast('Error al cargar datos por agente', 'danger');
      console.error('Error cargarPorAgente:', error);
    }
  }

  getColorByIndex(index: number): string {
    const colors = ['#FF6384', '#36A2EB', '#FFCE56', '#8E44AD', '#2ECC71', '#E67E22'];
    return colors[index % colors.length];
  }

  exportChart() {
    const canvas: any = document.querySelector('canvas');
    const image = canvas.toDataURL('image/png');
    const link = document.createElement('a');
    link.href = image;
    link.download = 'dashboard-chart.png';
    link.click();
  }

  exportarTablaAExcel(): void {
    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(this.dashboardDeptoEstado);
    const workbook: XLSX.WorkBook = { Sheets: { 'Tickets por Departamento': worksheet }, SheetNames: ['Tickets por Departamento'] };
    const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    const blob: Blob = new Blob([excelBuffer], { type: 'application/octet-stream' });

    FileSaver.saveAs(blob, `tickets_departamento_${this.fechaInicio}_a_${this.fechaFin}.xlsx`);
  }
  formatearHorasDecimal(valor: number | null | undefined): string {
    if (valor == null || valor === 0) {
      return '–';
    }

    const horas = Math.floor(valor);
    const minutos = Math.round((valor - horas) * 60);

    let resultado = '';
    if (horas > 0) {
      resultado += `${horas} h`;
    }
    if (minutos > 0) {
      resultado += `${horas > 0 ? ' ' : ''}${minutos} min`;
    }

    return resultado || '–';
  }
  public getFilasFiltradas(): any[] {
    return this.dashboardDeptoEstado.filter(item =>
      item.Abierto > 0 ||
      item.Asignado > 0 ||
      item.EnProgreso > 0 ||
      item.Cerrado > 0 ||
      item.Reaperturado > 0 ||
      item.Escalado > 0 ||
      item.TiempoRespuestaTotal > 0 ||
      item.TiempoRespuestaPromedio > 0 ||
      item.TiempoServicioTotal > 0 ||
      item.TiempoServicioPromedio > 0
    );
  }

  getTotales(): any {
    const total = {
      DepartamentoNombre: 'TOTAL',
      Abierto: 0,
      Asignado: 0,
      EnProgreso: 0,
      Cerrado: 0,
      Reaperturado: 0,
      Escalado: 0,
      TiempoRespuestaTotal: 0,
      TiempoRespuestaPromedio: 0,
      TiempoServicioTotal: 0,
      TiempoServicioPromedio: 0,
      TotalTickets: 0
    };

    const filas = this.getFilasFiltradas();

    for (const item of filas) {
      total.Abierto += Number(item.Abierto);
      total.Asignado += Number(item.Asignado);
      total.EnProgreso += Number(item.EnProgreso);
      total.Cerrado += Number(item.Cerrado);
      total.Reaperturado += Number(item.Reaperturado);
      total.Escalado += Number(item.Escalado);

      total.TiempoRespuestaTotal += Number(item.TiempoRespuestaTotal);
      total.TiempoRespuestaPromedio += Number(item.TiempoRespuestaPromedio);
      total.TiempoServicioTotal += Number(item.TiempoServicioTotal);
      total.TiempoServicioPromedio += Number(item.TiempoServicioPromedio);

      total.TotalTickets +=
        Number(item.Abierto) + Number(item.Asignado) + Number(item.EnProgreso) +
        Number(item.Cerrado) + Number(item.Reaperturado) + Number(item.Escalado);
    }

    const count = filas.length || 1;
    total.TiempoRespuestaPromedio = total.TiempoRespuestaPromedio / count;
    total.TiempoServicioPromedio = total.TiempoServicioPromedio / count;

    return total;
  }

  async mostrarPopoverTickets(ev: any, item: any) {
    const popover = await this.popoverController.create({
      component: PopoverResumenTicketsComponent,
      componentProps: { item },
      event: ev,
      translucent: true,
      showBackdrop: true
    });
    await popover.present();
  }

  getTotalTicketsFila(item: any): number {
    return (
      Number(item.Abierto) +
      Number(item.Asignado) +
      Number(item.EnProgreso) +
      Number(item.Cerrado) +
      Number(item.Reaperturado) +
      Number(item.Escalado)
    );
  }

  //grafico barras
  // Gráfico de barras por agente
  barChartData: ChartData<'bar'> = {
    labels: [],
    datasets: [
      {
        label: 'Tickets por Estado',
        data: [],
        backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#8E44AD', '#2ECC71', '#E67E22']
      }
    ]
  };

  barChartType: 'bar' = 'bar';


  barChartOptions: ChartOptions<'bar'> = {
    responsive: true,
    maintainAspectRatio: false,
    indexAxis: 'y',
    plugins: {
      legend: {
        position: 'bottom', // ✅ Mantenemos leyenda a la derecha
        labels: {
          font: {
            size: 8
          },
          boxWidth: 10,
          boxHeight: 12
        }
      },
      datalabels: {
        anchor: 'center',
        align: 'center',
        color: '#000',
        font: {
          size: 8,
          weight: 'bold'
        },
        formatter: (value: number) => (value > 0 ? value : '')
      }
    },
    scales: {
      x: {
        beginAtZero: true,
        ticks: {
          font: {
            size: 8
          }
        }
      },
      y: {
        ticks: {
          font: {
            size: 8
          }
        }
      }
    }
  };


  getDynamicChartHeight(): string {
    const rows = this.dashboardAgente.length || 1;
    const altura = rows * 40;
    return `${Math.min(altura, 500)}px`; // máx 500px
  }




  barChartPlugins: Plugin[] = [ChartDataLabels];


  exportarGraficoAgente() {
    const canvas: HTMLCanvasElement = this.barChartAgenteCanvasRef?.nativeElement;

    if (canvas) {
      const image = canvas.toDataURL('image/png');
      const link = document.createElement('a');
      link.href = image;
      link.download = `grafico_agente_${this.fechaInicio}_a_${this.fechaFin}.png`;
      link.click();
    } else {
      this.showToast('No se encontró el gráfico para exportar', 'warning');
    }
  }

  // async cargarSatisfaccionUsuario() {
  //   if (!this.fechaInicio || !this.fechaFin) {
  //     this.showToast('Debes seleccionar ambas fechas', 'warning');
  //     return;
  //   }

  //   const endpoint = `controllers/ticket.controller.php?op=dashboardencuesta&fechaInicio=${this.fechaInicio}&fechaFin=${this.fechaFin}`;
  //   try {
  //     const data = await (await this.apiService.get(endpoint)).toPromise() as any[];
  //     this.dashboardSatisfaccion = data;
  //   } catch (error) {
  //     this.showToast('Error al cargar datos de satisfacción', 'danger');
  //     console.error('Error cargarSatisfaccionUsuario:', error);
  //   }
  // }

  async cargarSatisfaccionUsuario() {
    if (!this.fechaInicio || !this.fechaFin) {
      this.showToast('Debes seleccionar ambas fechas', 'warning');
      return;
    }

    const fechaInicioFormatted = this.fechaInicio.slice(0, 10);
    const fechaFinFormatted = this.fechaFin.slice(0, 10);

    try {
      const endpoint = `controllers/ticket.controller.php?op=dashboardencuesta&fechaInicio=${fechaInicioFormatted}&fechaFin=${fechaFinFormatted}`;
      const data: any = await (await this.apiService.get(endpoint)).toPromise();
      this.dashboardSatisfaccion = data;
      //
      this.renderGraficoNPS();
    } catch (error) {
      this.showToast('Error al cargar datos de satisfacción', 'danger');
      console.error('Error cargarSatisfaccionUsuario:', error);
    }
  }


  // exportarSatisfaccionAExcel(): void {
  //   const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(this.dashboardSatisfaccion);
  //   const workbook: XLSX.WorkBook = { Sheets: { 'Satisfacción': worksheet }, SheetNames: ['Satisfacción'] };
  //   const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
  //   const blob: Blob = new Blob([excelBuffer], { type: 'application/octet-stream' });

  //   FileSaver.saveAs(blob, `satisfaccion_usuarios_${this.fechaInicio}_a_${this.fechaFin}.xlsx`);
  // }

  exportarTablaSatisfaccionExcel(): void {
    if (!this.dashboardSatisfaccion || !this.dashboardSatisfaccion.length) {
      this.showToast('No hay datos para exportar', 'warning');
      return;
    }

    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(this.dashboardSatisfaccion);
    const workbook: XLSX.WorkBook = {
      Sheets: { 'Satisfacción': worksheet },
      SheetNames: ['Satisfacción']
    };
    const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    const blob: Blob = new Blob([excelBuffer], { type: 'application/octet-stream' });

    FileSaver.saveAs(blob, `satisfaccion_tickets_${this.fechaInicio}_a_${this.fechaFin}.xlsx`);
  }

  exportarTablaSatisfaccionAgenteExcel(): void {
    if (!this.tablaSatisfaccion || !this.tablaSatisfaccion.length) {
      this.showToast('No hay datos para exportar', 'warning');
      return;
    }

    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(this.tablaSatisfaccion);
    const workbook: XLSX.WorkBook = {
      Sheets: { 'Satisfacción por Agente': worksheet },
      SheetNames: ['Satisfacción por Agente']
    };
    const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    const blob: Blob = new Blob([excelBuffer], { type: 'application/octet-stream' });

    FileSaver.saveAs(blob, `satisfaccion_agente_${this.fechaInicio}_a_${this.fechaFin}.xlsx`);
  }


  tablaSatisfaccion: any[] = [];

  pieChartSatisfaccionPlugins: Plugin[] = [ChartDataLabels];

  pieChartSatisfaccionData: ChartData = {
    labels: [],
    datasets: [{
      data: [],
      backgroundColor: ['#f39c12', '#e67e22', '#e74c3c', '#8e44ad', '#3498db', '#1abc9c']
    }]
  };

  pieChartSatisfaccionType: ChartType = 'pie';

  pieChartSatisfaccionOptions: ChartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'bottom',
        labels: {
          font: {
            size: 12
          },
          padding: 20
        }
      },
      datalabels: {
        formatter: (value, ctx) => {
          const total = (ctx.chart.data.datasets[0].data as number[]).reduce((a, b) => a + b, 0);
          return `${((value * 100) / total).toFixed(1)}%`;
        },
        color: '#fff',
        font: {
          size: 10,
          weight: 'bold'
        }
      }
    }
  };


  async cargarResumenSatisfaccionAgente() {
    const endpoint = `controllers/ticket.controller.php?op=dashboardEncuestaAgente&fechaInicio=${this.fechaInicio}&fechaFin=${this.fechaFin}`;
    try {
      const data = await (await this.apiService.get(endpoint)).toPromise() as any[];

      if (!data || data.length === 0) {
        this.showToast('No hay datos de satisfacción por agente', 'warning');
        return;
      }

      this.tablaSatisfaccion = data;

      this.pieChartSatisfaccionData = {
        labels: data.map(d => d.agente),
        datasets: [{
          data: data.map(d => parseFloat(d.promedioPuntuacion)),
          backgroundColor: [
            '#FF6384', '#36A2EB', '#FFCE56',
            '#4BC0C0', '#9966FF', '#FF9F40'
          ]
        }]
      };
    } catch (error) {
      this.showToast('Error al cargar resumen de satisfacción por agente', 'danger');
      console.error(error);
    }
    this.renderVelocimetroComparativo();




    this.renderVelocimetroComparativo();




  }


  exportarGraficoSatisfaccion() {
    const canvas: HTMLCanvasElement = document.querySelector('canvas')!;
    if (canvas) {
      const image = canvas.toDataURL('image/png');
      const link = document.createElement('a');
      link.href = image;
      link.download = 'grafico_satisfaccion_agente.png';
      link.click();
    } else {
      this.showToast('No se encontró el gráfico para exportar', 'warning');
    }
  }
  // velocimetro



  // renderVelocimetroComparativo() {
  //   if (!this.tablaSatisfaccion?.length) {
  //     this.showToast('No hay datos para el velocímetro', 'warning');
  //     return;
  //   }

  //   const data = this.tablaSatisfaccion.map((item: any, index: number) => {
  //     return {
  //       type: 'indicator',
  //       mode: 'gauge+number',
  //       value: parseFloat(item.promedioPuntuacion),
  //       title: { text: item.agente, font: { size: 8 } },
  //       domain: { row: 0, column: index },
  //       gauge: {
  //         axis: { range: [0, 10] },
  //         bar: { color: '#34495e' }, // Color de la aguja del valor (puedes personalizar uno diferente por agente)
  //         steps: [
  //           { range: [0, 4], color: '#e74c3c' },   // Rojo
  //           { range: [4, 8], color: '#f1c40f' },   // Amarillo
  //           { range: [8, 10], color: '#2ecc71' }   // Verde
  //         ],
  //         threshold: {
  //           line: {
  //             color: this.getColorForValue(parseFloat(item.promedioPuntuacion)),
  //             width: 4
  //           },
  //           value: parseFloat(item.promedioPuntuacion)
  //         }
  //       }
  //     };
  //   });

  //   const layout: Partial<any> = {
  //     grid: { rows: Math.ceil(data.length / 2), columns: 2, pattern: 'independent' },
  //     margin: { t: 30, b: 30, l: 10, r: 10 },
  //     paper_bgcolor: '#fff',
  //     plot_bgcolor: '#fff',
  //   };


  //   Plotly.newPlot('graficoVelocimetro', data, layout);
  // }

  graficoVelocimetroAltura = '400px'; // valor por defecto

  // renderVelocimetroComparativo() {
  //   if (!this.tablaSatisfaccion?.length) {
  //     this.showToast('No hay datos para el velocímetro', 'warning');
  //     return;
  //   }

  //   const columns = 2; // ✅ Puedes cambiar a 3 si deseas 3 gráficos por fila
  //   const rows = Math.ceil(this.tablaSatisfaccion.length / columns);

  //   const data = this.tablaSatisfaccion.map((item: any, index: number) => ({
  //     type: 'indicator',
  //     mode: 'gauge+number',
  //     value: parseFloat(item.promedioPuntuacion),
  //     title: { text: item.agente, font: { size: 10 } },
  //     domain: {
  //       row: Math.floor(index / columns),
  //       column: index % columns
  //     },
  //     gauge: {
  //       axis: { range: [0, 10] },
  //       bar: { color: '#34495e' },
  //       steps: [
  //         { range: [0, 4], color: '#e74c3c' },
  //         { range: [4, 8], color: '#f1c40f' },
  //         { range: [8, 10], color: '#2ecc71' }
  //       ],
  //       threshold: {
  //         line: {
  //           color: this.getColorForValue(parseFloat(item.promedioPuntuacion)),
  //           width: 4
  //         },
  //         value: parseFloat(item.promedioPuntuacion)
  //       }
  //     }
  //   }));

  //   // const layout: Partial<any> = {
  //   //   grid: { rows, columns, pattern: 'independent' },
  //   //   margin: { t: 30, b: 30, l: 10, r: 10 },
  //   //   height: rows * 220, // 🔸 Aumenta la altura por fila si es necesario
  //   //   paper_bgcolor: '#fff',
  //   //   plot_bgcolor: '#fff',
  //   // };
  //   const altura = rows * 220;
  //   this.graficoVelocimetroAltura = `${altura}px`;

  //   const layout: Partial<any> = {
  //     grid: { rows, columns, pattern: 'independent' },
  //     margin: { t: 30, b: 30, l: 10, r: 10 },
  //     height: altura,
  //     paper_bgcolor: '#fff',
  //     plot_bgcolor: '#fff',
  //   };

  //   Plotly.newPlot('graficoVelocimetro', data, layout);
  // }

  // renderVelocimetroComparativo() {
  //   const contenedor = document.getElementById('graficoVelocimetro');
  //   if (!this.tablaSatisfaccion?.length || !contenedor) {
  //     this.showToast('No hay datos para el velocímetro', 'warning');
  //     return;
  //   }
  
  //   Plotly.purge(contenedor); // 🧹 limpia el gráfico anterior
  
  //   const columns = 2;
  //   const rows = Math.ceil(this.tablaSatisfaccion.length / columns);
  //   const altura = rows * 220;
  //   this.graficoVelocimetroAltura = `${altura}px`;
  
  //   const data = this.tablaSatisfaccion.map((item: any, index: number) => ({
  //     type: 'indicator',
  //     mode: 'gauge+number',
  //     value: parseFloat(item.promedioPuntuacion),
  //     title: { text: item.agente, font: { size: 10 } },
  //     domain: {
  //       row: Math.floor(index / columns),
  //       column: index % columns
  //     },
  //     gauge: {
  //       axis: { range: [0, 10] },
  //       bar: { color: '#34495e' },
  //       steps: [
  //         { range: [0, 4], color: '#e74c3c' },
  //         { range: [4, 8], color: '#f1c40f' },
  //         { range: [8, 10], color: '#2ecc71' }
  //       ],
  //       threshold: {
  //         line: {
  //           color: this.getColorForValue(parseFloat(item.promedioPuntuacion)),
  //           width: 4
  //         },
  //         value: parseFloat(item.promedioPuntuacion)
  //       }
  //     }
  //   }));
  
  //   const layout: Partial<any> = {
  //     grid: { rows, columns, pattern: 'independent' },
  //     margin: { t: 30, b: 30, l: 10, r: 10 },
  //     height: altura,
  //     paper_bgcolor: '#fff',
  //     plot_bgcolor: '#fff',
  //   };
  
  //   const config = { responsive: true, displayModeBar: false };
  
  //   Plotly.newPlot('graficoVelocimetro', data, layout, config); // 🔁 Redibuja con animación
  // }
  
  renderVelocimetroComparativo() {
    if (!this.tablaSatisfaccion?.length) {
      this.showToast('No hay datos para el velocímetro', 'warning');
      return;
    }
  
    const columns = 2;
    const rows = Math.ceil(this.tablaSatisfaccion.length / columns);
    const altura = rows * 220;
    this.graficoVelocimetroAltura = `${altura}px`;
  
    const data = this.tablaSatisfaccion.map((item: any, index: number) => ({
      type: 'indicator',
      mode: 'gauge+number',
      value: parseFloat(item.promedioPuntuacion),
      title: { text: item.agente, font: { size: 10 } },
      domain: {
        row: Math.floor(index / columns),
        column: index % columns
      },
      gauge: {
        axis: { range: [0, 10] },
        bar: { color: '#34495e' },
        steps: [
          { range: [0, 4], color: '#e74c3c' },
          { range: [4, 8], color: '#f1c40f' },
          { range: [8, 10], color: '#2ecc71' }
        ],
        threshold: {
          line: {
            color: this.getColorForValue(parseFloat(item.promedioPuntuacion)),
            width: 4
          },
          value: parseFloat(item.promedioPuntuacion)
        }
      }
    }));
  
    const layout: Partial<any> = {
      grid: { rows, columns, pattern: 'independent' },
      margin: { t: 30, b: 30, l: 10, r: 10 },
      height: altura,
      paper_bgcolor: '#fff',
      plot_bgcolor: '#fff',
    };
  
    const config = { responsive: true, displayModeBar: false };
  
    // 🟢 Usamos react con transición para animar
    const container = document.getElementById('graficoVelocimetro');
    if (container) {
      Plotly.react(container, data, layout, config).then(() => {
        Plotly.animate(container, {
          data: data
        }, {
          transition: { duration: 500, easing: 'cubic-in-out' },
          frame: { duration: 500 }
        });
      });
    }
  }
  
  getColorForValue(valor: number): string {
    if (valor <= 4) return '#e74c3c'; // rojo
    if (valor <= 8) return '#f1c40f'; // amarillo
    return '#2ecc71'; // verde
  }


  exportarGraficoVelocimetro() {
    Plotly.toImage('graficoVelocimetro', { format: 'png', height: 400, width: 800 }).then((dataUrl: string) => {
      const a = document.createElement('a');
      a.href = dataUrl;
      a.download = 'velocimetro_comparativo.png';
      a.click();
    });
  }

  // NPS

  calcularNPS(): number {
    const respuestas = this.dashboardSatisfaccion.map(e => Number(e.puntuacion)).filter(n => !isNaN(n));
    const total = respuestas.length;

    if (total === 0) return 0;

    const promotores = respuestas.filter(p => p >= 9).length;
    const detractores = respuestas.filter(p => p <= 6).length;

    const porcentajePromotores = (promotores / total) * 100;
    const porcentajeDetractores = (detractores / total) * 100;

    return Math.round(porcentajePromotores - porcentajeDetractores);
  }

  getNPSColor(nps: number): string {
    if (nps >= 50) return 'success';      // verde
    if (nps >= 0) return 'warning';        // amarillo
    return 'danger';                       // rojo
  }

  // renderGraficoNPS() {
  //   const nps = this.calcularNPS();

  //   const data = [{
  //     type: 'indicator',
  //     mode: 'gauge+number',
  //     value: nps,
  //     title: { text: "NPS", font: { size: 18 } },
  //     gauge: {
  //       axis: { range: [-100, 100] },
  //       bar: { color: '#34495e' },
  //       steps: [
  //         { range: [-100, 0], color: '#e74c3c' },
  //         { range: [0, 50], color: '#f1c40f' },
  //         { range: [50, 100], color: '#2ecc71' }
  //       ],
  //       threshold: {
  //         line: {
  //           color: this.getColorForValue(nps),
  //           width: 4
  //         },
  //         value: nps
  //       }
  //     }
  //   }];

  //   const layout = {
  //     width: 400,
  //     height: 250,
  //     margin: { t: 30, b: 0, l: 0, r: 0 },
  //     paper_bgcolor: '#fff',
  //     font: { color: '#333' }
  //   };

  //   Plotly.newPlot('graficoNPS', data, layout);
  // }

  // renderGraficoNPS() {
  //   const nps = this.calcularNPS();

  //   const contenedor = document.getElementById('graficoNPS');
  //   if (contenedor) {
  //     Plotly.purge(contenedor); // Limpia si ya existe
  //   }

  //   const data = [{
  //     type: 'indicator',
  //     mode: 'gauge+number',
  //     value: nps,
  //     title: { text: "NPS", font: { size: 16 } },
  //     domain: { x: [0, 1], y: [0, 1] },
  //     gauge: {
  //       shape: "semi", // Semicírculo
  //       axis: { range: [-100, 100], tickwidth: 1, tickcolor: "darkgray" },
  //       bar: { color: '#34495e' },
  //       steps: [
  //         { range: [-100, 0], color: '#e74c3c' },
  //         { range: [0, 50], color: '#f1c40f' },
  //         { range: [50, 100], color: '#2ecc71' }
  //       ],
  //       threshold: {
  //         line: {
  //           color: this.getColorForValue(nps),
  //           width: 4
  //         },
  //         value: nps
  //       }
  //     }
  //   }];

  //   const layout: Partial<any> = {
  //     margin: { t: 30, b: 0, l: 20, r: 20 },
  //     height: 220,
  //     paper_bgcolor: '#fff',
  //     plot_bgcolor: '#fff',
  //     font: { color: '#2c3e50', family: 'Arial' }
  //   };

  //   const config = {
  //     displayModeBar: false, // Oculta la barra de herramientas
  //     responsive: true
  //   };

  //   // ⏳ Dibuja primero con valor 0 para animar después
  //   const tempData = JSON.parse(JSON.stringify(data));
  //   tempData[0].value = 0;

  //   Plotly.newPlot('graficoNPS', tempData, layout, config).then(() => {
  //     // 🔁 Animación de entrada
  //     Plotly.animate('graficoNPS', {
  //       data: [{ value: nps }],
  //       traces: [0],
  //       layout: {}
  //     }, {
  //       transition: { duration: 800, easing: 'cubic-in-out' },
  //       frame: { duration: 500 }
  //     });
  //     // 🔁 Solución: Forzar redimensionamiento tras 500ms
  //     setTimeout(() => {
  //       Plotly.Plots.resize('graficoNPS');
  //     }, 500);

  //   });
  // }

  // renderGraficoNPS() {
  //   const nps = this.calcularNPS();
  
  //   const contenedor = document.getElementById('graficoNPS');
  //   if (!contenedor) {
  //     this.showToast('Contenedor del gráfico NPS no encontrado', 'danger');
  //     return;
  //   }
  
  //   Plotly.purge(contenedor); // limpia cualquier render previo
  
  //   const data = [{
  //     type: 'indicator',
  //     mode: 'gauge+number',
  //     value: nps,
  //     title: { text: "NPS", font: { size: 16 } },
  //     domain: { row: 0, column: 0 },
  //     gauge: {
  //       axis: { range: [-100, 100], tickwidth: 1, tickcolor: "darkgray" },
  //       bar: { color: '#34495e' },
  //       steps: [
  //         { range: [-100, 0], color: '#e74c3c' },
  //         { range: [0, 50], color: '#f1c40f' },
  //         { range: [50, 100], color: '#2ecc71' }
  //       ],
  //       threshold: {
  //         line: {
  //           color: this.getColorForValue(nps),
  //           width: 4
  //         },
  //         value: nps
  //       }
  //     }
  //   }];
  
  //   const layout: Partial<any> = {
  //     grid: { rows: 1, columns: 1, pattern: 'independent' },
  //     margin: { t: 30, b: 20, l: 10, r: 10 },
  //     height: 250,
  //     paper_bgcolor: '#fff',
  //     plot_bgcolor: '#fff'
  //   };
  
  //   // Esperamos al siguiente ciclo de detección para asegurar que el div esté bien renderizado
  //   setTimeout(() => {
  //     Plotly.newPlot(contenedor, data, layout).then(() => {
  //       Plotly.Plots.resize(contenedor); // 🔄 fuerza a Plotly a adaptarse al tamaño real
  //     });
  //   }, 100);
  // }
  
  // renderGraficoNPS() {
  //   const nps = this.calcularNPS();
  
  //   const contenedor = document.getElementById('graficoNPS');
  //   if (!contenedor) return;
  
  //   Plotly.purge(contenedor);
  
  //   const data = [{
  //     type: 'indicator',
  //     mode: 'gauge+number',
  //     value: nps,
  //     title: { text: "NPS", font: { size: 14 } },
  //     domain: { x: [0, 1], y: [0, 1] }, // usar todo el espacio disponible
  //     gauge: {
  //       axis: { range: [-100, 100], tickwidth: 1, tickcolor: "darkgray" },
  //       bar: { color: '#34495e' },
  //       steps: [
  //         { range: [-100, 0], color: '#e74c3c' },
  //         { range: [0, 50], color: '#f1c40f' },
  //         { range: [50, 100], color: '#2ecc71' }
  //       ],
  //       threshold: {
  //         line: {
  //           color: this.getColorForValue(nps),
  //           width: 4
  //         },
  //         value: nps
  //       }
  //     }
  //   }];
  
  //   // const layout: Partial<any> = {
  //   //   margin: { t: 30, b: 10, l: 0, r: 0 }, // menos margen izquierdo y derecho
  //   //   width: 400, // 🔧 prueba con 400 o incluso 350
  //   //   height: 250,
  //   //   paper_bgcolor: '#fff',
  //   //   plot_bgcolor: '#fff'
  //   // };
  //   const layout: Partial<any> = {
  //     width: 380, // Fijo y controlado
  //     height: 250,
  //     margin: { t: 30, b: 20, l: 20, r: 10 },
  //     paper_bgcolor: '#fff',
  //     plot_bgcolor: '#fff'
  //   };
    
  //   setTimeout(() => {
  //     Plotly.newPlot(contenedor, data, layout).then(() => {
  //       Plotly.Plots.resize(contenedor);
  //     });
  //   }, 100);
  // }
  

  // renderGraficoNPS() {
  //   const nps = this.calcularNPS();
  
  //   const contenedor = document.getElementById('graficoNPS');
  //   if (!contenedor) return;
  
  //   const data = [{
  //     type: 'indicator',
  //     mode: 'gauge+number',
  //     value: nps,
  //     title: { text: "NPS", font: { size: 16 } },
  //     domain: { row: 0, column: 0 },
  //     gauge: {
  //       axis: { range: [-100, 100], tickwidth: 1, tickcolor: "darkgray" },
  //       bar: { color: '#34495e' },
  //       steps: [
  //         { range: [-100, 0], color: '#e74c3c' },
  //         { range: [0, 50], color: '#f1c40f' },
  //         { range: [50, 100], color: '#2ecc71' }
  //       ],
  //       threshold: {
  //         line: {
  //           color: this.getColorForValue(nps),
  //           width: 4
  //         },
  //         value: nps
  //       }
  //     }
  //   }];
  
  //   const layout: Partial<any> = {
  //     width: 380,
  //     height: 250,
  //     margin: { t: 30, b: 20, l: 20, r: 10 },
  //     paper_bgcolor: '#fff',
  //     plot_bgcolor: '#fff'
  //   };
  
  //   const config = { responsive: true };
  
  //   // Usar Plotly.react en lugar de newPlot
  //   Plotly.react(contenedor, data, layout, config).then(() => {
  //     Plotly.animate(contenedor, {
  //       data: [{ value: nps }],
  //       traces: [0],
  //       layout: {}
  //     }, {
  //       transition: {
  //         duration: 800,
  //         easing: 'cubic-in-out'
  //       },
  //       frame: {
  //         duration: 800
  //       }
  //     });
  //   });
  // }
  
  renderGraficoNPS() {
    const nps = this.calcularNPS();
  
    const contenedor = document.getElementById('graficoNPS');
    if (!contenedor) return;
  
    const columns = 2;
    const rows = Math.ceil(this.tablaSatisfaccion.length / columns);
    const altura = rows * 220;
    // this.graficoVelocimetroAltura = `${altura}px`;

    const baseData = [{
      type: 'indicator',
      mode: 'gauge+number',
      value: 0, // Empieza en 0 para animar
      title: { text: "NPS", font: { size: 16 } },
      domain: { row: 0, column: 0 },
      gauge: {
        axis: { range: [-100, 100], tickwidth: 1, tickcolor: "darkgray" },
        bar: { color: '#34495e' },
        steps: [
          { range: [-100, 0], color: '#e74c3c' },
          { range: [0, 50], color: '#f1c40f' },
          { range: [50, 100], color: '#2ecc71' }
        ],
        threshold: {
          line: {
            color: this.getColorForValue(nps),
            width: 4
          },
          value: nps
        }
      }
    }];
  
    // const layout: Partial<any> = {
    //   width: 380,
    //   height: 250,
    //   margin: { t: 30, b: 20, l: 20, r: 10 },
    //   paper_bgcolor: '#fff',
    //   plot_bgcolor: '#fff'
    // };

    const layout: Partial<any> = {
      grid: { rows, columns, pattern: 'independent' },
      margin: { t: 30, b: 30, l: 100, r: 10 },
      height: altura,
      paper_bgcolor: '#fff',
      plot_bgcolor: '#fff',

          // 👇 Aquí están las caritas con colores
    annotations: [
      {
        text: '😞',
        font: { size: 28, color: '#e74c3c' },
        x: -0.2, y: 0.1,
        xref: 'paper',
        yref: 'paper',
        showarrow: false
      },
      {
        text: '😊',
        font: { size: 28, color: '#2ecc71' },
        x: 0.5, y: 0.1,
        xref: 'paper',
        yref: 'paper',
        showarrow: false
      }
    ]
    };
  
    const config = { responsive: true };
  
    // 1. Crear el gráfico con valor 0
    Plotly.newPlot(contenedor, baseData, layout, config).then(() => {
      // 2. Animar hasta el valor real
      Plotly.animate(contenedor, {
        data: [{ value: nps }],
        traces: [0],
        layout: {}
      }, {
        transition: {
          duration: 1000,
          easing: 'cubic-in-out'
        },
        frame: {
          duration: 1000
        }
      });
    });
  }
  

  exportarGraficoNPS() {
    Plotly.toImage('graficoNPS', { format: 'png', width: 400, height: 250 }).then((dataUrl: string) => {
      const a = document.createElement('a');
      a.href = dataUrl;
      a.download = 'nps_radial.png';
      a.click();
    });
  }

  getClaseNPS(): string {
    const nps = this.calcularNPS();

    if (nps >= 75) return 'nps-excelente';
    if (nps >= 50) return 'nps-muybien';
    if (nps >= 0) return 'nps-razonable';
    return 'nps-malo';
  }

  ionViewDidEnter() {
    // Se asegura de que se renderice el gráfico cuando la vista ya está lista
    setTimeout(() => {
      this.renderGraficoNPS();
    }, 300); // puedes ajustar el delay si es necesario
  }
  
  // ionAccordionAbierto(tab: string) {
  //   if (tab === 'npsGrafico') {
  //     setTimeout(() => this.renderGraficoNPS(), 50);
  //   }
  
  //   if (tab === 'velocimetro') {
  //     setTimeout(() => this.renderVelocimetroComparativo(), 50);
  //   }
  // }
  
  ionAccordionAbierto(valor: string) {
    this.tabSeleccionada = valor;
  
    // Renderiza el velocímetro comparativo si se abre
    if (valor === 'velocimetro') {
      setTimeout(() => this.renderVelocimetroComparativo(), 50);
    }
  
    // Renderiza el gráfico radial del NPS si se abre
    if (valor === 'npsGrafico') {
      setTimeout(() => this.renderGraficoNPS(), 50);
    }
  }
  

}
